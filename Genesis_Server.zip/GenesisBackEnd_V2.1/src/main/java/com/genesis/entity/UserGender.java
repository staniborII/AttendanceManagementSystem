package com.genesis.entity;

public enum UserGender {
	MALE, FEMALE;
}
