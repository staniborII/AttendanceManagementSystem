package com.genesis.entity;

public enum Role {
	ADMIN,USER;
}
